#include "stdafx.h"

int NumberOf1Between1AndN(int n)
{
	return 0;
}